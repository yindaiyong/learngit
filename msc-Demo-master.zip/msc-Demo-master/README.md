# msc-Demo
微服务学习Demo

- microservicecloud文件夹为IDEA版，我为其写上详细的注释
- microservicecloud-eclipse为eclipse版，我在网上拿到的资源
